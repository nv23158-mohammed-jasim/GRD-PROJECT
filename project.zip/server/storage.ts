import { db } from "./db";
import {
  entries,
  workoutSessions,
  gameSessions,
  boxingSessions,
  type CreateEntryRequest,
  type EntryResponse,
  type CreateWorkoutSessionRequest,
  type WorkoutSessionResponse,
  type CreateGameSessionRequest,
  type GameSessionResponse,
  type CreateBoxingSessionRequest,
  type BoxingSessionResponse
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // Entry methods
  getEntries(): Promise<EntryResponse[]>;
  createEntry(entry: CreateEntryRequest): Promise<EntryResponse>;
  deleteEntry(id: number): Promise<void>;
  
  // Workout session methods
  getWorkoutSessions(): Promise<WorkoutSessionResponse[]>;
  createWorkoutSession(session: CreateWorkoutSessionRequest): Promise<WorkoutSessionResponse>;
  deleteWorkoutSession(id: number): Promise<void>;
  
  // Game session methods
  getGameSessions(): Promise<GameSessionResponse[]>;
  createGameSession(session: CreateGameSessionRequest): Promise<GameSessionResponse>;
  deleteGameSession(id: number): Promise<void>;
  
  // Boxing session methods
  getBoxingSessions(): Promise<BoxingSessionResponse[]>;
  createBoxingSession(session: CreateBoxingSessionRequest): Promise<BoxingSessionResponse>;
  deleteBoxingSession(id: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // Entry methods
  async getEntries(): Promise<EntryResponse[]> {
    return await db.select().from(entries).orderBy(desc(entries.date));
  }

  async createEntry(entry: CreateEntryRequest): Promise<EntryResponse> {
    const [created] = await db.insert(entries).values(entry).returning();
    return created;
  }

  async deleteEntry(id: number): Promise<void> {
    await db.delete(entries).where(eq(entries.id, id));
  }

  // Workout session methods
  async getWorkoutSessions(): Promise<WorkoutSessionResponse[]> {
    return await db.select().from(workoutSessions).orderBy(desc(workoutSessions.date));
  }

  async createWorkoutSession(session: CreateWorkoutSessionRequest): Promise<WorkoutSessionResponse> {
    const [created] = await db.insert(workoutSessions).values(session).returning();
    return created;
  }

  async deleteWorkoutSession(id: number): Promise<void> {
    await db.delete(workoutSessions).where(eq(workoutSessions.id, id));
  }

  // Game session methods
  async getGameSessions(): Promise<GameSessionResponse[]> {
    return await db.select().from(gameSessions).orderBy(desc(gameSessions.date));
  }

  async createGameSession(session: CreateGameSessionRequest): Promise<GameSessionResponse> {
    const [created] = await db.insert(gameSessions).values(session).returning();
    return created;
  }

  async deleteGameSession(id: number): Promise<void> {
    await db.delete(gameSessions).where(eq(gameSessions.id, id));
  }

  // Boxing session methods
  async getBoxingSessions(): Promise<BoxingSessionResponse[]> {
    return await db.select().from(boxingSessions).orderBy(desc(boxingSessions.date));
  }

  async createBoxingSession(session: CreateBoxingSessionRequest): Promise<BoxingSessionResponse> {
    const [created] = await db.insert(boxingSessions).values(session).returning();
    return created;
  }

  async deleteBoxingSession(id: number): Promise<void> {
    await db.delete(boxingSessions).where(eq(boxingSessions.id, id));
  }
}

export const storage = new DatabaseStorage();
